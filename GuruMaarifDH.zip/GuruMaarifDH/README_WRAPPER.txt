Open with Android Studio. If Gradle wrapper is missing, Android Studio will create/update it automatically.
